
import tensorflow as tf
from tensorflow import keras

from tensorflow_model_optimization.quantization.keras import *

from tensorflow_model_optimization.python.core.quantization.keras.default_8bit  \
    import (
      default_8bit_quantize_layout_transform, 
      default_8bit_quantize_registry
    )


from tensorflow_model_optimization.python.core.quantization.keras \
  import quantize_registry, quantize_config, quantize_scheme, quantize_annotate
from tensorflow_model_optimization.python.core.sparsity.keras \
  import prune_registry, prunable_layer, pruning_schedule
from tensorflow_model_optimization.python.core.quantization.keras import quantizers


from ifx_tfmot_utl import pruning_quantizers 


class DefaultPruneQuantizeConfigRNN(default_8bit_quantize_registry.Default8BitQuantizeConfigRNN):

  """QuantizeConfig for Incrementatal Pruning RNN layers."""

  def __init__(self, pruning_sched, weight_attrs, activation_attrs, quantize_output):
    super(DefaultPruneQuantizeConfigRNN,
          self).__init__(weight_attrs, activation_attrs, quantize_output)

    self.weight_quantizer = pruning_quantizers.ScheduledLowMagnitudePruning(pruning_sched)


class DefaultPruneQuantizeConfig(default_8bit_quantize_registry.Default8BitQuantizeConfig):

  """QuantizeConfig for Non-RNN layers."""

  def __init__(self, pruning_sched, weight_attrs, activation_attrs, quantize_output):
    super(DefaultPruneQuantizeConfig,
          self).__init__(weight_attrs, activation_attrs, quantize_output)

    self.weight_quantizer = pruning_quantizers.ScheduledLowMagnitudePruning(pruning_sched)


PruneRegistry = prune_registry.PruneRegistry


class DefaultPruneQuantRegistry(quantize_registry.QuantizeRegistry):

  """QuantizeRegistry for pruning (layers on PruneRegistery)
  """
  def __init__(self, pruning_sched=pruning_schedule.ConstantSparsity(0.5, 0), ignore=None):

    super(DefaultPruneQuantRegistry,self).__init__()

    self.pruning_schedule = pruning_sched
    self.ignore = ignore if ignore is not None else lambda layer : False

  def _get_prunable_weights(self, layer):

    # Handle ignored layers / RNN layers treating theim/their cells as
    # having no prunable weights
    ignored = self.ignore(layer)

    if PruneRegistry._is_rnn_layer(layer):
      prunable_weights = []
      for cell in PruneRegistry._get_rnn_cells(layer):
        if ignored:
          cell_weights = []
        elif isinstance(cell, prunable_layer.PrunableLayer):
          cell_weights = cell.get_prunable_weights()
        else:
          cell_weights = PruneRegistry._RNN_CELLS_WEIGHTS_MAP.get(cell.__class__, [])
        prunable_weights.append(cell_weights)
    else:
      if ignored:
        prunable_weights = []
      elif isinstance(layer, prunable_layer.PrunableLayer):
        prunable_weights = layer.get_prunable_weights()
      else:
        prunable_weights = PruneRegistry._LAYERS_WEIGHTS_MAP.get(layer.__class__, [])

    return prunable_weights


  def get_quantize_config(self, layer):
    """Get QuatnizeConfig derived for pruning injection mased on PruneRegistry
    """

    if not PruneRegistry.supports(layer):
        raise ValueError(
          '`get_quantize_config()` called on an unsupported layer {}. Check '
          'if layer is supported by calling `supports()`. Alternatively, you '
          'can use `QuantizeConfig` to specify a behavior for your layer.'
          .format(layer.__class__))

    eff_prunable_weights = self._get_prunable_weights(layer)

    if PruneRegistry._is_rnn_layer(layer):    
        return DefaultPruneQuantizeConfigRNN(
          pruning_sched=self.pruning_schedule,
          weight_attrs=eff_prunable_weights,
          activation_attrs=[],
          quantize_output=False
        )
    else:
        return DefaultPruneQuantizeConfig(
          pruning_sched=self.pruning_schedule,
          weight_attrs=eff_prunable_weights,
          activation_attrs=[],
          quantize_output=False
        )

  def supports(self, layer):

    return PruneRegistry.supports(layer)


def _compose_attr_quantizers(fst_attrs, snd_attrs, fst_quantizer, snd_quantizer):


    if fst_attrs and not isinstance(fst_attrs[0],str):
      # Nested attribute lists (e.g. for cells of RNN strcuture) - handle recursively preserving
      # Structure....
      assert snd_attrs and not isinstance(snd_attrs[0]), "Inconsistent sub-layer strctures"
      assert len(fst_attrs) == len(snd_attrs), "Inconsistent number of sub-layers"

      return [_compose_attr_quantizers(l,r, fst_quantizer, snd_quantizer) 
               for l,r in zip(fst_attrs, snd_attrs)
      ]
        
    else:
      # Simple layer - merge attributes, composing quantizers if to be injected
      # to same attribute.
      attrs_and_quantizers = []
      all_attrs = set(fst_attrs + snd_attrs)
      for attr in all_attrs:
        if attr in fst_attrs:
          if attr in snd_attrs:
            quantizer = pruning_quantizers.ComposedQuantizer(fst_quantizer, snd_quantizer)
          else:
            quantizer = fst_quantizer
        else:
          quantizer = snd_quantizer
        attrs_and_quantizers.append((attr, quantizer))
      return attrs_and_quantizers


class ComposedQuantizeConfig(quantize_config.QuantizeConfig):

  def __init__(self, fst, snd): 

      self.weight_attr_quants = \
        _compose_attr_quantizers(
            fst.weight_attrs, snd.weight_attrs,
            fst.weight_quantizer, snd.weight_quantizer
        )

      self.activation_attr_quants = \
        _compose_attr_quantizers(
            fst.activation_attrs, snd.activation_attrs,
            fst.activation_quantizer, snd.activation_quantizer
        )
      self.output_quantizers = []
      if fst.quantize_output:
        self.output_quantizers.append(fst.activation_quantizer)
      if snd.quantize_output:
        self.output_quantizers.append(snd.activation_quantizer)
      
      self.fst = fst
      self.snd = snd

  def get_weights_and_quantizers(self, layer):
    return [(getattr(layer, weight_attr), weight_quantizer)
            for weight_attr,weight_quantizer in self.weight_attr_quants]

  def get_activations_and_quantizers(self, layer):
    return [(getattr(layer, activation_attr), activation_quantizer)
            for activation_attr, activation_quantizer in self.activation_attr_quants]

  def set_quantize_weights(self, layer, quantize_weights):
    if len(self.weight_attr_quants) != len(quantize_weights):
      raise ValueError(
          '`set_quantize_weights` called on layer {} with {} '
          'weight parameters, but layer expects {} values.'.format(
              layer.name, len(quantize_weights), len(self.weight_attrs)))

    for (weight_attr,_), weight in zip(self.weight_attr_quants, quantize_weights):
      current_weight = getattr(layer, weight_attr)
      if current_weight.shape != weight.shape:
        raise ValueError('Existing layer weight shape {} is incompatible with'
                         'provided weight shape {}'.format(
                             current_weight.shape, weight.shape))

      setattr(layer, weight_attr, weight)

  def set_quantize_activations(self, layer, quantize_activations):
    if len(self.activation_attr_quants) != len(quantize_activations):
      raise ValueError(
          '`set_quantize_activations` called on layer {} with {} '
          'activation parameters, but layer expects {} values.'.format(
              layer.name, len(quantize_activations),
              len(self.activation_attrs)))

    for (activation_attr,_), activation in \
        zip(self.activation_attr_quants, quantize_activations):
      setattr(layer, activation_attr, activation)

  def get_output_quantizers(self, layer):
    return  self.output_quantizers

  @classmethod
  def from_config(cls, config):
    """Instantiates a `ComposedQuantizeConfig` from its config.

    Args:
        config: Output of `get_config()`.

    Returns:
        A `Default8BitQuantizeConfig` instance.
    """
    return cls(**config)

  def get_config(self):
    # TODO(pulkitb): Add weight and activation quantizer to config.
    # Currently it's created internally, but ideally the quantizers should be
    # part of the constructor and passed in from the registry.
    return {
        'fst': tf.keras.utils.serialize_keras_object(self.fst),
        'snd': tf.keras.utils.serialize_keras_object(self.snd),
    }

  def __eq__(self, other):
    if not isinstance(other, ComposedQuantizeConfig):
      return False

    return (self.fst == other.fst and
            self.snd == other.snd)

  def __ne__(self, other):
    return not self.__eq__(other)


class NoopQuantRegistry(quantize_registry.QuantizeRegistry):

  """QuantizeRegistry for pruning (layers on PruneRegistery)
  """
  def __init__(self):

    super(NoopQuantRegistry,self).__init__()


  def get_quantize_config(self, layer):
    """Get QuatnizeConfig derived for pruning injection mased on PruneRegistry
    """

    raise ValueError(
      '`get_quantize_config()` called on an unsupported layer {}. Check '
      'if layer is supported by calling `supports()`. Alternatively, you '
      'can use `QuantizeConfig` to specify a behavior for your layer.'
      .format(layer.__class__))


  def supports(self, layer):

    return False



class PruningQuantizeRegistry(quantize_registry.QuantizeRegistry):

  def __init__(self, 
    quant_registry = None,
    prune_registry = None
    ):

    self.quant_registry = \
      default_8bit_quantize_registry.Default8BitQuantizeRegistry() if quant_registry is None else quant_registry
    self.prune_registry = \
      DefaultPruneQuantRegistry(pruning_schedule.ConstantSparsity(0.5, 0)) if prune_registry is None else prune_registry

  def get_quantize_config(self, layer):
    """Returns the  config for pruing and/or quantization of the given layer.

      Constructed by mergeing activation attrs for 
    Args:
      layer: input layer to return quantize config for.

    Returns:
      Returns the QuantizeConfig for the given layer.
    """

    # Layer up 
    try:
      prune_config = self.prune_registry.get_quantize_config(layer)
    except ValueError:
      prune_config = None
    try:
      quant_config = self.quant_registry.get_quantize_config(layer)
    except ValueError:
      quant_config = None



    if prune_config:
      if quant_config:
        return ComposedQuantizeConfig(prune_config, quant_config)
      else:
        return prune_config
    else:
      if quant_config:
        return quant_config
      else:
        raise ValueError('Invalid Layer type {} - not supported for either pruning or quantization'.format(layer.__class__))


  def supports(self, layer):

    return self.prune_registry.supports(layer) or self.quant_registry.supports(layer)




class Pruning8BitQuantizeScheme(quantize_scheme.QuantizeScheme):

  def __init__(self, 
        pruning_sched=pruning_schedule.ConstantSparsity(0.5, 0),    
        quant_registry = None,
        prune_registry = None,
        prune_ignore = None):

      super(Pruning8BitQuantizeScheme,self).__init__()

      if prune_ignore and prune_registry:
        raise ValueError("prune_ignore ar is ignored if prune_registry arg is passed.")
      if prune_ignore is None:
        prune_ignore = lambda _: False
      
      self.pruning_sched = pruning_sched
      self.quant_registry = \
        default_8bit_quantize_registry.Default8BitQuantizeRegistry() if quant_registry is None else quant_registry
      self.prune_registry = \
          DefaultPruneQuantRegistry(pruning_sched, prune_ignore) if prune_registry is None else prune_registry



  def get_layout_transformer(self):
    return default_8bit_quantize_layout_transform.\
        Default8BitQuantizeLayoutTransform()

  def get_quantize_registry(self):
    return PruningQuantizeRegistry(
      quant_registry=self.quant_registry,
      prune_registry=self.prune_registry
    )


class PruningTestQuantizeScheme(quantize_scheme.QuantizeScheme):

  def __init__(self, pruning_sched=pruning_schedule.ConstantSparsity(0.5, 0)):

      super(PruningTestQuantizeScheme,self).__init__()
      self.pruning_sched = pruning_sched


  def get_layout_transformer(self):
    return default_8bit_quantize_layout_transform.\
        Default8BitQuantizeLayoutTransform()

  def get_quantize_registry(self):    
    return PruningQuantizeRegistry(
      #prune_registry=NoopQuantRegistry()
      prune_registry=DefaultPruneQuantRegistry(pruning_sched=self.pruning_sched),
      quant_registry=NoopQuantRegistry()
      )
    



class DelayedStartEmaQuantizeScheme(quantize_scheme.QuantizeScheme):

  def __init__(self, ema_decay=0.99, delay=100):

      super(DelayedStartEmaQuantizeScheme,self).__init__()
      self.ema_decay = ema_decay
      self.delay = delay


  def get_layout_transformer(self):
    return default_8bit_quantize_layout_transform.Default8BitQuantizeLayoutTransform()

  def get_quantize_registry(self):
    return default_8bit_quantize_registry.Default8BitQuantizeRegistry(
        weight_ema_decay=self.ema_decay, act_ema_decay=self.ema_decay, delay=self.delay
    )



class Sub8BitDSConvQuantizeConfig(default_8bit_quantize_registry.Default8BitQuantizeConfig):

    """
    Quantization Configuration allowing specification of quantization bitwidth of
    kernels.
    """
    def __init__(self, num_bits):

        super(Sub8BitDSConvQuantizeConfig,self).__init__(['depthwise_kernel'], ['activation'],False)

        self.num_bits = num_bits
        # Override hard-wired 8-bit default
        self.weight_quantizer = quantizers.LastValueQuantizer(
            num_bits=num_bits, per_axis=False, symmetric=True, narrow_range=True)

    def get_config(self):
        return {
            "num_bits": self.num_bits
        }


class Sub8BitQuantizeConfig(default_8bit_quantize_registry.Default8BitQuantizeConfig):

    """
    Quantization Configuration allowing specification of quantization bitwidth of
    kernels.
    """
    def __init__(self, num_bits):

        super(Sub8BitQuantizeConfig,self).__init__(['kernel'], ['activation'],False)

        self.num_bits = num_bits
        # Override hard-wired 8-bit default
        self.weight_quantizer = quantizers.LastValueQuantizer(
            num_bits=num_bits, per_axis=False, symmetric=True, narrow_range=True)

    def get_config(self):
        return {
            "num_bits": self.num_bits
        }


class Sub8BitQuantizeConfigRNN(default_8bit_quantize_registry.Default8BitQuantizeConfigRNN):

    """
    Quantization Configuration allowing specification of quantization bitwidth of
    kernels.
    """
    def __init__(self, num_bits):

        super(Sub8BitQuantizeConfigRNN,self).__init__(['kernel'], ['activation'],False)

        self.num_bits = num_bits
        # Override hard-wired 8-bit default
        self.weight_quantizer = quantizers.LastValueQuantizer(
            num_bits=num_bits, per_axis=False, symmetric=True, narrow_range=True)

    def get_config(self):
        return {
            "num_bits": self.num_bits
        }




def layer_annotator(quant_config):

    if quant_config is None:
        return lambda x: x
    else:
        return lambda layer : quantize_annotate_layer(layer, quant_config)



def custom_quantize_model(
    model,
    scheme,
    *args):

    """
    Wrapper for tfmot quantization that automatically constructs
    quantization_context needed to use  custom QuantizationConfig .


    :param model: model to tansform into QAT form
    :type model: keras.Model
    """
    # Its super-tedious to have to manual list custom objects used for QuantizationConfig s
    # so walk the model and collect any we don't recognize...

    custom_objects = dict()
    layers = model.layers[:]
    while layers:

        l = layers.pop()
        if isinstance(l, keras.Model):
            layers += l.layers
        elif isinstance(l, quantize_annotate.QuantizeAnnotate):
            config_object = l.quantize_config
            config_class = config_object.__class__
            if not isinstance(config_object, QuantizeConfig):
                raise ValueError("Unexpected class quantize_config of QuantizeAnnotate Wrapper " + l.name +
                                 " not an instance quantize_config.QuantizeConfig: " + config_class.__name__)
            custom_objects[config_class.__name__] = config_class

    with quantize_scope(custom_objects):
        annotated_model = quantize_annotate_model(model)
        return quantize_apply(annotated_model, scheme=scheme, *args)
