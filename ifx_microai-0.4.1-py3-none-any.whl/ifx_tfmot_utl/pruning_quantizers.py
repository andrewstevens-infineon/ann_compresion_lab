# Copyright 2021 Infineon Technologies. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Quantizer classes which implement pruning / using tfmot Quantizer API for Uniformity.

Module: quuant
"""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf

from tensorflow_model_optimization.python.core.quantization.keras import quantizers
from tensorflow_model_optimization.python.core.sparsity.keras import pruning_schedule as pruning_sched

keras = tf.keras


@tf.custom_gradient
def straight_through_mask(input, mask):
    def grad(dy):
        return (dy, input * dy)
    return tf.multiply(mask, input), grad




class ScheduledLowMagnitudePruning(quantizers.Quantizer):

    """ Low magnitude incremental pruing implemented as a Quantizer

    This is an experimental API not subject to backward compatibility.

    """

    def __init__(
            self,
            pruning_schedule = pruning_sched.ConstantSparsity(0.5, 0)
            ):

        self.pruning_schedule = pruning_schedule


    def build(self, tensor_shape, name, layer):

        step_counter = layer.add_weight(
            name=name+"_prune_step",
            shape=[],
            dtype=tf.dtypes.int64,
            initializer=tf.constant_initializer(0),
            trainable=False,
            use_resource=False,
        )
        sparsity = layer.add_weight(
            name=name+"_sparsity",
            shape=[],
            dtype=tf.float32,
            initializer=tf.constant_initializer(0.5),
            trainable=False,
        )

        pruning_mask = layer.add_weight(
            name=name+"_mask",
            shape=tensor_shape,
            dtype=tf.dtypes.float32,
            initializer=tf.constant_initializer(1),
            trainable=False,
        )

        self.pruning_mask = pruning_mask
        return {'step_counter': step_counter,
                'sparsity': sparsity,
                'pruning_mask': pruning_mask}

    def __call__(self, inputs, training, weights, **kwargs):
        """Quantize tensor.

        Args:
          inputs: Input tensor to be quantized.
          training: Whether the graph is currently training.
          weights: Dictionary of weights the quantizer can use to quantize the
            tensor. This contains the weights created in the `build` function.
          **kwargs: Additional variables which may be passed to the quantizer.

        Returns:
          Quantized tensor.
        """

        pruning_mask = weights['pruning_mask']
        def no_update_mask():
            return pruning_mask

        if training:

            step_counter = weights['step_counter']
            #sparsity = weights['sparsity']

            step_counter.assign(tf.math.add(
                step_counter, tf.constant(1, dtype=tf.int64)))
            is_update_mask_step,sparsity =self.pruning_schedule(step_counter)

            def update_mask():
                abs_inputs = tf.math.abs(inputs)
                masked_kernel_index = tf.dtypes.cast(
                    tf.maximum(1.0,
                        tf.math.round(
                            tf.dtypes.cast(tf.size(abs_inputs), tf.float32)
                            * tf.math.subtract(1.0, sparsity)
                        )
                    ),
                    tf.int32,
                )

                sorted_inputs, _ = tf.math.top_k(
                    tf.reshape(abs_inputs, [-1]), k=masked_kernel_index
                )
                current_threshold = sorted_inputs[masked_kernel_index-1]
                return pruning_mask.assign(
                    tf.dtypes.cast(
                        tf.math.greater_equal(
                            abs_inputs, current_threshold), inputs.dtype
                    )
                )
            latest_mask = tf.cond(is_update_mask_step, update_mask, no_update_mask)
        else:
            latest_mask = no_update_mask()

        masked_inputs = straight_through_mask(inputs, latest_mask)

        return masked_inputs

    def get_config(self):
        return {
            'pruning_schedule':  tf.keras.utils.serialize_keras_object(self.pruning_schedule),
        }

    def __eq__(self, other):
        if not isinstance(other, LowMagnitudePruning):
            return False

        return (self.begin_step == other.begin_step and
                self.end_step == other.end_step and
                self.initial_sparsity == other.initial_sparsity and
                self.final_sparsity == other.final_sparsity and
                self.power == other.power and
                self.frequency == other.frequency)

    def __ne__(self, other):
        return not self.__eq__(other)



class ComposedQuantizer(quantizers.Quantizer):

    def __init__(self, fst, snd):

        self.fst = fst
        self.snd = snd

    def build(self, tensor_shape, name, layer):

        fst_weights = self.fst.build(tensor_shape, name + '_fst', layer)
        snd_weights = self.snd.build(tensor_shape, name + '_snd', layer)
        weights = {}
        for k, v in fst_weights.items():
            weights['fst_'+k] = v
        for k, v in snd_weights.items():
            weights['snd_'+k] = v
        return weights

    def __call__(self, inputs, training, weights, **kwargs):

        fst_weights = {}
        snd_weights = {}
        for k, v in weights.items():
            root_k = k[4:]
            if k.startswith('fst_'):
                fst_weights[root_k] = v
            elif k.startswith('snd_'):
                snd_weights[root_k] = v
            else:
                assert False, "ill-formed weight key " + k

        fst_out = self.fst(inputs, training, fst_weights, **kwargs)
        snd_out = self.snd(fst_out, training, snd_weights, **kwargs)

        return snd_out

    def get_config(self):

        return {'fst': tf.keras.utils.serialize_keras_object(self.fst),
                'snd': tf.keras.utils.serialize_keras_object(self.snd)}
