import numpy as np
from typing import Callable, Optional, Union, Tuple




def uniform_quant_qminmax(bits=8, signed=False, narrow_range=False):

    if signed:
        two_pow_bits_1 = np.power(2.0, bits - 1)
        if narrow_range:
            return (-two_pow_bits_1+1, two_pow_bits_1-1)
        else:
            return (-two_pow_bits_1,two_pow_bits_1-1 )
    else:
        return (0.0, np.power(2.0, bits) - (2.0 if narrow_range else 1.0))


def uniform_quant_params(rmin, rmax, bits=8, signed=False, narrow_range=False):
    """
    Compute decode scale and zero_point for values quantized by google "fake_quant"

    :param    bits:   Bit precision for quantized encoding
    :param    rmin:    minimum value to be represented (not allowing for 0.0 adjustment)
    :param    rmax:    maximum  value to be represented (not allowing for 0.0 adjustment)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                       otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return:  scale factor for decoding after applying offset, zero_point code
    """

    qmin, qmax = uniform_quant_qminmax(bits, signed=signed, narrow_range=narrow_range)
    qbr = qmax - qmin
    qr = rmax - rmin  # Representation range
    scale = qr / qbr

    # Derive from tflite  ChooseQuantizationParams() from consistency....
    # Zero-point computation.
    # First the initial floating-point computation. The zero-point can be
    # determined from solving an affine equation for any known pair
    # (real value, corresponding quantized value).
    # We know two such pairs: (rmin, qmin) and (rmax, qmax).
    # The arithmetic error on the zero point computed from either pair
    # will be roughly machine_epsilon * (sum of absolute values of terms)
    # so we want to use the variant that adds the smaller terms.
    zero_point_from_min = qmin - rmin / scale
    zero_point_from_max = qmax - rmax / scale
    zero_point_from_min_error = abs(qmin) + abs(rmin / scale)
    zero_point_from_max_error = abs(qmax) + abs(rmax / scale)

    zero_point = (
      zero_point_from_min if zero_point_from_min_error < zero_point_from_max_error
      else zero_point_from_max
    )

    # Now we need to nudge the zero point to be an integer
    # (our zero points are integer, and this is motivated by the requirement
    # to be able to represent the real value "0" exactly as a quantized value,
    # which is required in multiple places, for example in Im2col with SAME
    # padding).

    if zero_point < qmin:
        nudged_zero_point = qmin
    elif zero_point > qmax:
        nudged_zero_point = qmax
    else:
        nudged_zero_point = round(zero_point)
    return scale, nudged_zero_point


def raw_uniform_encode(v, scale, zero):
    """
    Compute value of input after raw quantization with google "fake_quant"  uniform quantizer

    Raw quantization means no adjustment of offset to ensure exact coding of 0.0
    use rounding hear mirror tflite implementation QuantizeBuffer()
    Args:
    :param    v:      Value to encode
    :param    scale:  decode scale factor
    :param    zero:  zero code

    :return:  value encoded by quantized representation
    """

    # This is the precise formulation in Tenesflow's
    # fake quantization implementation.
    return np.floor(v / scale + zero  + 0.5)


def raw_uniform_decode(c, scale, zero):
    """
    Compute value of represented by code for google "fake_quant"  uniform quantizer

    Note this intentionally does not quantize the code c (this is
    intended to be done in `raw_uniform_encode`

    :param     c:      Code to decode
    :param     scale:  decode scale factor
    :param     zero:  zero code

    :return:   value encoded by quantized representation
    """
    return (c.astype(np.float) - zero) * scale


def uniform_quantizer(bits: int = 8,
                      min_max: Optional[Tuple[float, float]] = None,
                      scale_zero: Optional[Tuple[float, int]] = None,
                      signed=False,
                      narrow_range=False):
    """
    Quantizer for google "fake_quant"  uniform quantizer

    Underling offset is adjusted to ensure 0.0 has an exact representation at the expense
    of potentially truncation of values close to byt smaller than specified max
    or close to but larger than min
    

    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param     scale_zero: decode scale factor and zero code (alternative to min_max)
    :param     signed: signed codes
    :param     narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                       otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return:
        callable computing value encoded by quantized representation of its input
    """

    if min_max is not None:
        rmin, rmax = min_max
        scale, zero = uniform_quant_params(rmin, rmax, bits=bits, signed=signed, narrow_range=narrow_range)
    else:
        scale, zero = scale_zero
    qmin, qmax = uniform_quant_qminmax(bits=bits, signed=signed, narrow_range=narrow_range)

    def quantize(v):
        qc = raw_uniform_encode(v, scale, zero)
        clip_qc = np.clip(qc, qmin, qmax)
        qv = raw_uniform_decode(clip_qc, scale, zero)
        return qv

    return quantize


def uniform_decoder(bits: int = 8,
                    min_max: Optional[Tuple[float,float]] = None,
                    scale_zero: Optional[Tuple[float,int]] = None,
                    signed=False,
                    narrow_range=False):
    """
    Decoder for tensorflow/tflite "fake_quant" uniform quantizer

    Underling offset is adjusted to ensure 0.0 has an exact representation at the expense
    of potentially truncation of values close to byt smaller than specified max
    or close to but larger than min

    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param     scale_zero: decode scale factor and zero code (alternative to min_max)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                       otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return: A callable object computing value encoded by input code
    """

    if min_max is not None:
        rmin, rmax = min_max
        scale, zero = uniform_quant_params(rmin, rmax, bits=bits, signed=signed, narrow_range=narrow_range)
    else:
        scale, zero = scale_zero

    def decoder(c):
        qv = raw_uniform_decode(c, scale, zero)
        return qv

    return decoder


def uniform_encoder(bits:int = 8,
                    min_max:Optional[Tuple[float,float]] = None,
                    scale_zero:Optional[Tuple[float,int]] = None,
                    signed=False,
                    narrow_range=False):
    """
    Compute value of input after quantization with google "fake_quant"  uniform quantizer

    Underling offset is adjusted to ensure 0.0 has an exact representation at the expense
    of potentially truncation of values close to but smaller than specified max
    or close to but larger than min

    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param    scale_zero: decode scale factor and zero code (alternative to min_max)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
      otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return:  A callable computing encoding quantized representation of its input
    """

    if min_max is not None:
        rmin, rmax = min_max
        scale, zero = uniform_quant_params(rmin, rmax, bits=bits, signed=signed, narrow_range=narrow_range)
    else:
        scale, zero = scale_zero
    qmin, qmax = uniform_quant_qminmax(bits=bits, signed=signed, narrow_range=narrow_range)

    def encoder(v):
        qc = raw_uniform_encode(v, scale, zero)
        clip_qc = np.clip(qc, qmin, qmax)
        return clip_qc

    return encoder



def uniform_quantize(v, **kwargs):
    """
    Compute value of input after quantization with google "fake_quant"  uniform quantizer

    Underling offset is adjusted to ensure 0.0 has an exact representation at the expense
    of potentially truncation of values close to byt smaller than specified max
    or close to but larger than min

    :param    v:      Value to quantize
    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param     scale_zero: decode scale factor and zero code (alternative to min_max)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                       otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return:       value encoded by quantized representation of `v`
    """
    return uniform_quantizer(**kwargs)(v)


def uniform_decode(c, **kwargs):
    """
    Compute value represented by google "fake_quant"  uniform quantizer code

    Underling offset is adjusted to ensure 0.0 has an exact representation at the expense
    of potentially truncation of values close to byt smaller than specified max
    or close to but larger than min

    :param     c:      Value to decode
    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param    scale_zero: decode scale factor and zero code (alternative to min_max)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                       otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return:    value encoded by quantized representation `c`
    """

    return uniform_decoder(**kwargs)(c)


def uniform_encode(v, **kwargs):
    """
    Compute encoding of value when quantized by google "fake_quant" uniform quantizer

    :param    v:      Value to encode
    :param    bits:   Bit precision for quantized encoding
    :param    min_max: minimum/maximum value to be represented (not allowing for 0.0 adjustment)
    :param    scale_zero: decode scale factor and zero code (alternative to min_max)
    :param    signed: signed codes
    :param    narrow_range:  Use symmetrical encoding quantized codes [-(2^(bits-1)-1),2^(bits-1)-1]
                    otherwise uses all available codes [-2^(bits-1),2^(bits-1)-1]

    :return: coding of  quantized representation `v`
    """

    return uniform_encoder(**kwargs)(v)


