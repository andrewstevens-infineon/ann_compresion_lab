
"""Utilities to support model execution/debug using TF-Lite interpreter."""

import tensorflow as tf
import numpy as np
from .quantization import uniform_encoder, uniform_decoder


# TODO generalize to N inputs and N outputs by probing sized of _details attributes,

class FlatBufModel(object):

    """
    Wrapper for tflite.Interpreter run simple single-input single-output
    tflite model that exposes compatible interface to keras.Model

    Automatically quantizes/dequantizer inputs and outputs as required.\
    By default uses the slooow reference kernels to ensure  a close match
    with tflite(u).
    """
    def __init__(self,  flatbuff_name,
                 in_bits=8, out_bits=8,
                 input_dtype=np.uint8,
                 tflite_op_type="ref"):

        # TODO should probaby also auto-probe dtype/bits from inputs too!!
        if tflite_op_type == "ref":
            op_type = tf.lite.experimental.OpResolverType.BUILTIN_REF
        elif tflite_op_type == "builtin":
            op_type = tf.lite.experimental.OpResolverType.BUILTIN
        else:
            tflite_op_type = tf.lite.experimental.OpResolverType.AUTO

        self.input_dtype = input_dtype
        self.flatbuff_name = flatbuff_name
        self.interp = tf.lite.Interpreter(self.flatbuff_name, experimental_op_resolver_type=op_type)
        # Allocate memory for  model
        self.interp.allocate_tensors()

        in_details = self.interp.get_input_details()
        self.in_type = in_details[0]["dtype"]
        self.in_idx = in_details[0]["index"]
        if "quantization" in  in_details[0] and in_details[0]["quantization"][0] != 0.0:
            self.in_quantization = in_details[0]["quantization"]
            signed = self.in_type == np.int8
            self.in_quant = \
                uniform_encoder(
                    bits=in_bits, scale_zero=self.in_quantization, 
                    signed=signed)
            self.rq =  \
                uniform_encoder(
                    bits=in_bits, scale_zero=self.in_quantization)
        else:
            self.in_quant = lambda x: x

        out_details = self.interp.get_output_details()
        self.out_type =  out_details[0]["dtype"]
        self.out_idx = out_details[0]["index"]
        
        if "quantization" in  out_details[0] and in_details[0]["quantization"][0] != 0.0:
            self.out_quantization = out_details[0]["quantization"]
            signed = self.out_type == np.int8
            self.out_dequant = \
                uniform_decoder(
                    bits=out_bits, scale_zero=self.out_quantization, 
                    signed=signed)
            self.rd = uniform_decoder(
                    bits=out_bits, scale_zero=self.out_quantization)
        else:
            self.out_dequant = lambda x: x


    def predict(self, x):
        
        """
        Run inference on the wrapped quantized tflite model.   if input is missing batch dimension
        this is added.   Takes care to avoid dangling references to
        internal tflite buffers between inferences.
        """
        in_tensor = self.interp.tensor(self.in_idx)()
        x_quant =  self.in_quant(x)
        x_quant = x_quant.astype(self.in_type)

        if (1,) + x_quant.shape == in_tensor.shape:
            x_quant = x_quant.reshape((1,) + x_quant.shape)
        if x_quant.shape != in_tensor.shape:
            raise Exception( f"Model input tensor shape {in_tensor.shape} != input shape {x_quant.shape}")
        for i in range(x_quant.shape[0]):
            in_tensor[i] = x_quant[i]
        in_tensor = None
        self.interp.invoke()
        y_quant = self.interp.get_tensor(self.out_idx)
        y = self.out_dequant(y_quant)
        return y

    def predict_qdbg(self, x):

        """
        Run inference on the wrapped quantized tflite model.   if niput is missing batch dimension
        this is added.   Takes care to avoid dangling references to
        internal tflite buffers between inferences.
        """
        in_tensor = self.interp.tensor(self.in_idx)()
        x_quant = self.in_quant(x)
        x_quant = x_quant.astype(self.in_type)

        if (1,) + x_quant.shape == in_tensor.shape:
            x_quant = x_quant.reshape((1,) + x_quant.shape)
        if x_quant.shape != in_tensor.shape:
            raise Exception(f"Model input tensor shape {in_tensor.shape} != input shape {x_quant.shape}")
        for i in range(x_quant.shape[0]):
            in_tensor[i] = x_quant[i]
        in_tensor = None
        self.interp.invoke()
        y_quant = self.interp.get_tensor(self.out_idx)
        y = self.out_dequant(y_quant)
        return (y, x_quant, y_quant)
