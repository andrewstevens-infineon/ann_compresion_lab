# Copyright 2017 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================


import os.path
import os



_ALIGNED_MACRO_DEFN = \
"""
// We need to keep the data array aligned on some architectures.
#ifdef __has_attribute
#define HAVE_ATTRIBUTE(x) __has_attribute(x)
#else
#define HAVE_ATTRIBUTE(x) 0
#endif
#if HAVE_ATTRIBUTE(aligned) || (defined(__GNUC__) && !defined(__clang__))
#define DATA_ALIGN_ATTRIBUTE __attribute__((aligned(4)))
#else
#define DATA_ALIGN_ATTRIBUTE
#endif
"""

def write_C_array_src_and_hdr(desc, output_path, output_fnameroot,
                              byte_values=None,
                              src_datafile=None,
                              aligned=False,
                              C_type= 'uint8_t',
                              hdr_suffix=".h", src_suffix=".cc"):
    """
    Generate C source for byte array definition and declaration holding
     contents of specified file or byte array.
    
    :param desc:    Descriptive text commenting definition
    :param output_path:  Pathname of directory to generated header and source files.
    :param output_fnameroot: Filename root for generated header and source files.
    :param byte_values: Optional[Array[int]] byte values array is to hold.
    :param src_datafile: Optional[str] byte values array is to hold.
    :param aligned:     Add alignment attribute for GCC and CLANG.
    :param hdr_suffix:  Filetype suffix to use for generated header file (default: .h)
    :param src_suffix:  Filetype sufficx to use for generated source files (default: .cc)

    """

    hfilename = output_fnameroot+hdr_suffix
    cppfilename = output_fnameroot+src_suffix
    hfile_pname = os.path.join(output_path, hfilename)
    cppfile_pname = os.path.join(output_path, cppfilename)

    if C_type == 'int8_t':
        bmin = -128
        bmax = 127
    elif C_type == 'uint8_t':
        bmin = 0
        bmax = 255
    else:
        raise ValueError("C_type must be 'int8_t' or 'uint8_t'")
    if src_datafile:
        if byte_values is not None:
            raise ValueError("Cannot have both src_datafile and byte_values not None")
        with open(src_datafile, "rb") as tfl:
            byte_values = tfl.read()
    if byte_values is None:
        raise ValueError("Cannot have both src_datafile and byte_values None")

    with open(cppfile_pname, "w") as out:
        out.write("/**\n")
        out.write("* "+desc+"\n")
        out.write("*/\n\n")
        out.write(f"#include \"{hfilename}\"\n\n\n")
        if aligned:
            out.write(_ALIGNED_MACRO_DEFN)
            alignment_direction = ' DATA_ALIGN_ATTRIBUTE'
        else:
            alignment_direction = ''

        out.write(f"const {C_type} {output_fnameroot}_data[]{alignment_direction} =\n")
        out.write("{\n")
        i = 0
        for v in byte_values:
            byte = max(bmin, min(int(v),bmax))
            out.write(f"{byte:3}, ")
            i = i + 1
            if i % 20 == 0:
                out.write("\n")
        out.write("};\n\n")
        out.write(f"extern const size_t {output_fnameroot}_len = {i};\n")

    with open(hfile_pname, "w") as out:
        out.write("/**\n")
        out.write("* "+desc+"\n")
        out.write("*/\n\n")
        out.write("#pragma once\n");
        out.write("#include <stdint.h>\n")
        out.write("#include <stddef.h>\n\n")
        out.write(f"extern const {C_type} {output_fnameroot}_data[];\n")
        out.write(f"extern const size_t {output_fnameroot}_len;\n")


