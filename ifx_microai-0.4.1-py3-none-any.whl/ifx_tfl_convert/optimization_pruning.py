# %%
"""Main file for pruning optimization utility"""
import tensorflow as tf
import os
from ifx_tfl_convert.data_processing import *
import json
import logging
from tensorflow_model_optimization.python.core.sparsity.keras import prune
from ifx_tfl_convert.pruning_functions import *
from ifx_tfl_convert.models_comparer import run_and_compare_keras_tflite_models
gpu_devices = tf.config.list_physical_devices('GPU')
if gpu_devices:
  tf.config.set_logical_device_configuration(
    gpu_devices[0],
    [tf.config.LogicalDeviceConfiguration(memory_limit=200)])


def convert_model(pruned_keras_model, converter_config, test_data):
    """Main function for conversion stage
    Inputs:
            pruned_keras_model: dict with paths to models and data
            converter_config: dict with converter configuration
            test_data: list of numpy arrays with testing data
        Outputs:
            tflite_model: converted TFLite model
    """
    try:
        keras_model = prune.strip_pruning(pruned_keras_model)
        converter = tf.lite.TFLiteConverter.from_keras_model(keras_model)
    except Exception as e:
        error_message = "[ERROR] Keras model loading failed. "
        error_message += format(e)
        print (error_message)
        raise Exception
    if converter_config['convertion_type'] == "FLOAT":
        #set converter settings for FLOAT convertion
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.allow_custom_ops = False
        converter.inference_input_type = tf.float32
        converter.inference_output_type = tf.float32
    elif converter_config['convertion_type'] == 'INT8':
        #set converter settings for INT8 conversion
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
        converter.allow_custom_ops = True
        converter.target_spec.force_training_quant = False
        # Log the conversion process before every pass
        #converter.conversion_print_before_pass = "all"
        representative_dataset_generator = RepresentativeDatasetGenerator(test_data,converter_config['frame_size'], \
            converter_config['n_hop_frames'],converter_config['calibration_samples'])
        converter.representative_dataset = representative_dataset_generator
        # INput/output tensors will quantized representaiton -
        # no quantization/dequantization at I/O boundary in converted model
        converter.inference_input_type = tf.int8
        converter.inference_output_type = tf.int8  
    else:
        raise Exception("[ERROR] Invalid conversion type specified. Allowed only FLOAT and INT8")
    try:
        tflite_model = converter.convert()
    except Exception as e:
        error_message = "[ERROR] Model conversion failed. "
        error_message += format(e)
        print (error_message)
        logging.critical(e)
        raise Exception
    return tflite_model




def extract_paths_from_config(global_config):
    """Function for extraction paths to models and data from config file section
    Inputs:
            global_config: dict with global configuration
        Outputs:
            paths_config: dict with paths to models and data
            pruning_config: dict with pruning configuration
            converter_config: dict with converter configuration
    """
    try:
        paths_config     = global_config['data_paths']
        pruning_config   = global_config['pruning_configuration']
        converter_config = global_config['converter_configuration']

        paths_config['ifx_keras_model_root']  = paths_config['ifx_keras_model_root'].replace('/', os.path.sep)
        paths_config['ifx_keras_model_root']  = os.path.abspath(paths_config['ifx_keras_model_root'])
        paths_config['ifx_keras_model_name']  = f"""{paths_config['ifx_keras_model_root']}{os.path.sep}{paths_config['model_name_string']}.h5"""
        paths_config['ifx_tflite_folder']      = os.path.abspath(f"""{os.getcwd()}{os.path.sep}gen""")
        if not os.path.exists(paths_config['ifx_tflite_folder']):
            os.mkdir(paths_config['ifx_tflite_folder'])
        paths_config['ifx_tflite_name_string'] = f"{paths_config['model_name_string']}_{converter_config['convertion_type']}"
    except Exception as e:
        error_message = "[ERROR] Error in path extraction. "
        error_message += e
        print (error_message)
        raise Exception
    return paths_config, pruning_config, converter_config


def start_pruning_quantization_pipeline(config_file):
    """Main function for running utility pipeline
    Inputs:
            config_file: dict with global configuration
        Outputs:
           None
    """
    if not os.path.exists("logs"):
        os.mkdir("logs")
    logging.basicConfig(filename = f'logs{os.path.sep}global_running_log.log', level = logging.DEBUG)
    if os.path.isfile(config_file):
        #config_file      = "quantization_pruning_toolchain\\config\\config_mnist_small.json"
        global_config = json.load(open(config_file))
        paths_config, pruning_config, converter_config = extract_paths_from_config(global_config)
        pruning_config['n_hop_frames'] = converter_config['n_hop_frames']
        #read data for pipeline
        logging.info("Data reading...")
        try:
            array_x_test, array_y_test            = read_singlefile(paths_config['test_data_path'])
            array_x_train, array_y_train          = read_singlefile(paths_config['train_data_path'])
        except Exception as e:
            error_message = "PRUNING: Pruned model finetuning failed. "
            error_message += format(e)
            logging.critical(error_message)
            print (error_message) 
            raise Exception
        # %%
        logging.info("Model pruning and finetuning process started...")
        pruned_keras_model = setup_configuration_and_prune_model(paths_config, pruning_config, [array_x_train, array_y_train])
        logging.info("Model conversion process started...")
        converted_model = convert_model(pruned_keras_model, converter_config, array_x_test)
        #write converted model to tflite file
        logging.info("TFLite model saving...")
        if not os.path.exists(paths_config['ifx_tflite_folder']):
            os.mkdir(paths_config['ifx_tflite_folder'])
        with open(os.path.join(paths_config['ifx_tflite_folder'],\
            paths_config['ifx_tflite_name_string'] + '.tflite'), 'wb') as file_tflite:
            file_tflite.write(converted_model)
        logging.info("Models comparison started...")
        global_config['validation_results'] = run_and_compare_keras_tflite_models(paths_config, converter_config, array_x_test, array_y_test)
        #write working configuration to JSON
        global_config['data_paths'] = paths_config
        logging.info("Writing results...")
        with open(os.path.join(paths_config['ifx_tflite_folder'],\
            paths_config['ifx_tflite_name_string'] + '.json'), 'w') as file_json:
            #print (global_config)
            json.dump(global_config, file_json, indent = 2)
        logging.info("Done!")
    else:
        error_message = "[ERROR] Config file does not exist. "
        logging.critical(error_message)
        print (error_message)
        raise Exception
    
