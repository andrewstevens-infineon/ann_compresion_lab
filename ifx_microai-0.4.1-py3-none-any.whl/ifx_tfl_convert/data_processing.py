"""functions for reading HAR and MNIST formats"""
import os
import numpy as np
import tensorflow as tf
from tensorflow import keras

def read_singlefile(x_test_path):
    """Read singlefile model format

    Inputs:
            x_test_path:  path to csv test dataset (target col: 0)
        Outputs:
            array_x_test: numpy array of features cols
            array_y_test: numpy array with target data
    """
    array_x_test = None
    array_y_test = None
    array_x_test =  np.genfromtxt(x_test_path.replace('/',os.path.sep), delimiter=",")
    array_y_test = array_x_test[:,0]
    array_x_test = array_x_test[:,1:]
    return array_x_test, array_y_test
# %%
#array_y_test = 
def read_har(ifx_keras_model_root,x_test_path):
    """Read har model format

    Inputs:
            ifx_keras_model_root: str path root folder
            x_test_path:  path to csv test dataset
        Outputs:
            array_x_test: numpy array of features cols
            array_y_test: numpy array with target data
    """
    array_x_test = None
    array_y_test = None
    with open(x_test_path,'r') as file_paths_har_test:
        for num_line,line in enumerate(file_paths_har_test,1):
            path_class = ifx_keras_model_root + os.path.sep +  'har' + os.path.sep + line.replace('/', os.path.sep)[:-1]  
            if array_x_test is not None:
                array_class = np.genfromtxt(path_class, delimiter=",")
                array_x_test = np.concatenate((array_x_test, array_class), axis=1)
                addition_y = np.full((1,array_class.shape[1]),num_line-1)
                array_y_test = np.concatenate((array_y_test,addition_y),axis=1)
            else:    
                array_x_test =  np.genfromtxt(path_class, delimiter=",")
                array_y_test = np.full((1,array_x_test.shape[1]),num_line-1)
    array_x_test = array_x_test.transpose().astype(np.float32)
    array_y_test = array_y_test.transpose()
    return array_x_test,array_y_test


class RepresentativeDatasetGenerator():
    """Class for creating representative dataset generator with mutable parameters (according to config file)
        Members:
                - array_x_test - numpy array with testing dataset
                - frame_size - sample size
                - h_hop_frames - set additional dims for samples
                - n_samples - desired nums of samples
    """
    def __init__(self, array_x_test, frame_size, n_hop_frames,n_samples):
        self.array_x_test = array_x_test
        self.frame_size =  frame_size
        self.n_hop_frames = n_hop_frames
        self.n_samples = n_samples

    def __call__(self):
        for data in tf.data.Dataset.from_tensor_slices((self.array_x_test)).batch(self.frame_size).take(self.n_samples):
            if self.n_hop_frames > 0:
                data = np.expand_dims(data, axis = 0)
            yield [tf.dtypes.cast(data, tf.float32)]

class DataGenerator(keras.utils.Sequence):
    """Class for creating dataset generator for model finetuning with mutable parameters (according to config file)
        Members:
                - array_x_test - numpy array with features for testing dataset
                - array_y_test - numpy array with targets testing dataset
                - frame_size - sample size
                - h_hop_frames - set additional dims for samples
    """
    def __init__(self, array_x_test, array_y_test, frame_size, n_hop_frames):
        self.array_x_test = array_x_test
        self.array_y_test = array_y_test
        self.frame_size =  frame_size
        self.n_hop_frames = n_hop_frames
        self.num_batches = np.ceil(len(array_x_test) / self.frame_size)
        self.batch_idx = np.array_split(range(len(array_x_test)), self.num_batches)

    def __len__(self):
        return len(self.batch_idx)

    def __getitem__(self, idx):
        batch_x = self.array_x_test[self.batch_idx[idx]]
        batch_y = self.array_y_test[self.batch_idx[idx]]
        batch_y = np.max(batch_y, axis=0)
        if self.n_hop_frames == 1:
            batch_x = np.expand_dims(batch_x, axis=0)
        batch_y = np.expand_dims(batch_y, axis=0)
        return batch_x, batch_y