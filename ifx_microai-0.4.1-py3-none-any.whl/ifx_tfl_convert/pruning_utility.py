"CLI file for utility"
from argparse import ArgumentParser
from ifx_tfl_convert.optimization_pruning import start_pruning_quantization_pipeline

parser = ArgumentParser(description='MTB models tflite pipeline')
parser.add_argument('--config', type=str, nargs='+',
                    help='path to global config file')
args = parser.parse_args()
    

def main():
    start_pruning_quantization_pipeline(args.config[0])

# %%
if __name__=='__main__':
    main()
