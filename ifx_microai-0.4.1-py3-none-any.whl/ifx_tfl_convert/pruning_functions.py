import tensorflow as tf
import numpy as np
import tensorflow_model_optimization as tfmot
from ifx_tfl_convert.data_processing import *
import logging
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow_model_optimization.python.core.sparsity.keras import pruning_policy
from tensorflow import keras
gpu_devices = tf.config.list_physical_devices('GPU')
if gpu_devices:
  tf.config.set_logical_device_configuration(
    gpu_devices[0],
    [tf.config.LogicalDeviceConfiguration(memory_limit=200)])


class PruneOnlyMatchingNames(pruning_policy.PruningPolicy):
    """Class for setting custom pruning policy (per layer)
        Members:
            - to_prune - input mdodel
    """
    def __init__(self, to_prune):
        self.to_prune = to_prune

    def allow_pruning(self, layer):
        for pat in self.to_prune:
            if pat in layer.name:
                print( "Pruning:", layer.name)
                return True

        print( "NOT Pruning:", layer.name)
        return False
    
    def ensure_model_supports_pruning(self, model):
        pass


class PruneModelLayersByNames():
    """Class for setting custom pruning policy (custom level of pruning per layer)
        Members:
            - pruning_config -  (dict) per-layer pruning configuration
    """
    def __init__(self, pruning_config):
        self.pruning_config = pruning_config
        self.dictionary_pruning_layers = self.parse_pruning_per_layer_strategy_configuration(pruning_config)
        del pruning_config["per_layers"]

    @staticmethod
    def parse_pruning_per_layer_strategy_configuration(pruning_config):
        """Method for configuration parsing
        Members:
            - pruning_config -  (dict) per-layer pruning configuration
        """
        if "per_layers" in pruning_config.keys():
            per_layers_config = pruning_config["per_layers"]
            dictionary_pruning_layers = {}
            for layer_config in per_layers_config:
                dictionary_pruning_layers[layer_config['layer_name']] = layer_config["final_sparsity"]
        return dictionary_pruning_layers

    def __call__(self, layer):
        if layer.name in self.dictionary_pruning_layers.keys():
            layer_pruning_config = self.pruning_config
            layer_pruning_config['initial_sparsity'] = 0
            layer_pruning_config["final_sparsity"] = self.dictionary_pruning_layers[layer.name]
            pruning_params = {
                'pruning_schedule': tfmot.sparsity.keras.PolynomialDecay.from_config(layer_pruning_config)
                }
            return tfmot.sparsity.keras.prune_low_magnitude(layer,  **pruning_params)
        return layer

def setup_configuration_and_prune_model(paths_config, pruning_config, training_data):
    """Main function for pruning stage
    Inputs:
            paths_config: dict with paths to models and data
            pruning_config: dict with pruning configuration
            converter_config: dict with converter configuration
        Outputs:
            model_pruned: Keras pruned model object after finetuning
    """
    try:
        keras_model = keras.models.load_model(paths_config['ifx_keras_model_name'])
    except Exception as e:
        error_message = "PRUNING: Keras model loading failed. "
        error_message += format(e)
        logging.critical(error_message)
        raise Exception
    array_x, array_y = training_data[0], training_data[1]
    try:
        array_x_train, array_y_train = array_x[:int(len(array_x) * (1 - pruning_config['validation_split'])), :], \
        array_y[:int(len(array_x)*  (1 - pruning_config['validation_split']))]
        array_x_val, array_y_val = array_x[:int(len(array_x) * pruning_config['validation_split']), :], \
            array_y[:int(len(array_x) * pruning_config['validation_split'])]
        # Define model for pruning.
        num_samples = array_x_train.shape[0] * (1 - pruning_config['validation_split'])
        pruning_config['pruning_params']['end_step'] = \
            int(np.ceil(num_samples / pruning_config['batch_size']).astype(np.int32) * pruning_config['num_epochs'])
        dataset_train  =  DataGenerator(array_x_train, array_y_train, pruning_config['batch_size'], pruning_config['n_hop_frames'])
        dataset_val = DataGenerator(array_x_val, array_y_val, pruning_config['batch_size'], pruning_config['n_hop_frames'])
    except Exception as e:
        error_message = "PRUNING: Dataset preparation stage failed. "
        error_message += format(e)
        logging.critical(error_message)
        raise Exception
    try:
        if "per_layers" not in pruning_config['pruning_params'].keys():
            pruning_params = {
                    'pruning_schedule': tfmot.sparsity.keras.PolynomialDecay.from_config(pruning_config['pruning_params'])
                    }
            model_pruned = tfmot.sparsity.keras.prune_low_magnitude(keras_model,  **pruning_params)
        else:
            pruning_function = PruneModelLayersByNames(pruning_config['pruning_params'])
            model_pruned = tf.keras.models.clone_model(keras_model, clone_function=pruning_function)
        model_pruned.compile(optimizer = pruning_config['optimizer'],\
            loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),\
                metrics=pruning_config['metrics'])
        callbacks = [
        tfmot.sparsity.keras.UpdatePruningStep(),
        tfmot.sparsity.keras.PruningSummaries(log_dir='logs/'),
        ]
        if "early_stopping" in pruning_config:
            callbacks.append(EarlyStopping(monitor = 'val_loss', 
            patience = pruning_config['early_stopping']['patience'],
            min_delta = pruning_config['early_stopping']['min_delta']))
        model_pruned.fit(dataset_train, epochs=pruning_config['num_epochs'], validation_data = dataset_val, callbacks=callbacks)
    except Exception as e:
        error_message = "[ERROR] PRUNING: Pruned model finetuning failed. "
        error_message += format(e)
        logging.critical(error_message)
        raise Exception
    return model_pruned

