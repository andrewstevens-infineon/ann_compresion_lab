"""Functions for running different types of models"""
import os
from tensorflow import keras
import numpy as np
import tensorflow as tf


def run_tflite_model(interpreter, input_data_frame, config_converter):
    """Runs TFlite model

    Inputs:
            interpreter: object of loaded tflite model
            input_data_frame:  testing dataset
            config_converter: dictionary with converter configuration
        Outputs:
            output_data: numpy array with inference results
    """
    #get model details
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    #quantize input, if needed
    try:
        if input_details[0]['dtype'] == np.int8:
                input_scale, input_zero_point = input_details[0]["quantization"]
                input_data_frame = input_data_frame / input_scale + input_zero_point
        input_data_frame = tf.cast(input_data_frame, input_details[0]['dtype'])
        if config_converter['n_hop_frames'] > 0:
            input_data_frame = np.expand_dims(input_data_frame, axis=0)
        #set input tensor
        interpreter.set_tensor(input_details[0]['index'], input_data_frame)
    except Exception as e:
        error_message = "[ERROR] Error while preparing sample for inference. "
        error_message += format(e)
        print (error_message)
        raise Exception
    #run inference
    try:
        interpreter.invoke()
        output_data = interpreter.get_tensor(output_details[0]['index'])
        #transform output data to classification models
        output_data = np.full(config_converter['frame_size'],np.argmax(output_data))
    except Exception as e:
        error_message = "[ERROR] TFLite inference error. "
        error_message += format(e)
        print (error_message)
        raise Exception
    return output_data


def run_keras_model(keras_model, input_data_frame, config_converter):
    """Runs Keras h5 model

    Inputs:
            Keras model: object of loaded keras model
            input_data_frame:  testing dataset
            config_converter: dictionary with converter configuration
        Outputs:
            output_data: numpy array with inference results
    """
    #prepare input data
    if config_converter['n_hop_frames'] > 0:
        input_data_frame = np.expand_dims(input_data_frame, axis=0)
    input_data_frame = tf.cast(input_data_frame, tf.float32)
    #run inference
    output_data = keras_model.predict(input_data_frame)
    #transform output data to classification models
    output_data = np.full(config_converter['frame_size'],np.argmax(output_data))
    return output_data


def run_and_compare_keras_tflite_models(paths_config, converter_config, array_x_test, array_y_test):
    """Function for running inference and comparing results of converted TFLite and original Keras h5 model

    Inputs:
            paths_config: dict with paths to models
            converter_config: dictionary with converter configuration
            input_data_frame:  testing dataset
            array_x_test: numpy array of features cols
            array_y_test: numpy array with target data
        Outputs:
           dict with classification models comparison results
    """
    keras_model = keras.models.load_model(paths_config['ifx_keras_model_name'])
    try:
        interpreter = tf.lite.Interpreter(model_path = os.path.join(paths_config['ifx_tflite_folder'],\
                paths_config['ifx_tflite_name_string'] + '.tflite'))
        interpreter.allocate_tensors()
    except Exception as e:
        error_message = "[ERROR] Error while reading model. "
        error_message += format(e)
        print (error_message)
        raise Exception
   
    correct_counter_tflite = 0
    correct_counter_keras = 0

    dataset = tf.data.Dataset.from_tensor_slices((array_x_test,array_y_test)).batch(converter_config['frame_size'])
    for batch_data in dataset:
        input_data_frame = batch_data[0]
        if input_data_frame.shape[0] != converter_config["frame_size"]:
            continue
        output_data_frame_actual = batch_data[1]

        #apply inference on tflite interpreter
        output_data_frame_predicted_tflite = run_tflite_model(interpreter, input_data_frame, converter_config)
        if ((output_data_frame_actual.numpy()==output_data_frame_predicted_tflite).all()):
            correct_counter_tflite += 1
        #apply inference for keras model
        output_data_frame_predicted_keras = run_keras_model(keras_model, input_data_frame, converter_config)
        if ((output_data_frame_actual.numpy()==output_data_frame_predicted_keras).all()):
            correct_counter_keras += 1
    return ({
        'Samples': array_x_test.shape[0]//converter_config['frame_size'],
        'Correct_TFLite': correct_counter_tflite,
        'Accuracy_TFLite': correct_counter_tflite*100/(array_x_test.shape[0]//converter_config['frame_size']),
        'Correct_Keras': correct_counter_keras,
        'Accuracy_Keras': correct_counter_keras*100/(array_x_test.shape[0]//converter_config['frame_size'])})


def compare_pruned_with_original_model_keras(paths_config, converter_config, pruned_keras_model, test_array):
    """Function for running inference and comparing results of pruned and original Keras h5 model
    Inputs:
            paths_config: dict with paths to models
            pruned_keras_model: pruned keras model
            test_data: list of numpy arrays with testing data
        Outputs:
           dict with classification models comparison results
    """
    keras_model_original = keras.models.load_model(paths_config['ifx_keras_model_name'])
    correct_counter_pruned = 0
    correct_counter_original = 0

    dataset = tf.data.Dataset.from_tensor_slices((test_array[0],test_array[1])).batch(converter_config['frame_size'])
    for batch_data in dataset:
        input_data_frame = batch_data[0]
        if input_data_frame.shape[0] != converter_config["frame_size"]:
            continue
        output_data_frame_actual = batch_data[1]

        #apply inference on tflite interpreter
        output_data_frame_predicted_pruned = run_keras_model(pruned_keras_model, input_data_frame, converter_config)
        if ((output_data_frame_actual.numpy()==output_data_frame_predicted_pruned).all()):
            correct_counter_pruned += 1
        #apply inference for keras model
        output_data_frame_predicted_keras = run_keras_model(keras_model_original, input_data_frame, converter_config)
        if ((output_data_frame_actual.numpy()==output_data_frame_predicted_keras).all()):
            correct_counter_original += 1
        #print(output_data_frame_actual)
        #print(output_data_frame_predicted)
        #print (((output_data_frame_actual.numpy()==output_data_frame_predicted_keras).all()))
    return ({
        'Samples': test_array[0].shape[0]//converter_config['frame_size'],
        'Correct_Pruned': correct_counter_pruned,
        'Accuracy_Pruned': correct_counter_pruned*100/(test_array[0].shape[0]//converter_config['frame_size']),
        'Correct_Original': correct_counter_original,
        'Accuracy_Original': correct_counter_original*100/(test_array[0].shape[0]//converter_config['frame_size'])})
