import sys
import argparse

if __name__ == "__main__":
    from sub8_and_sparse import packTflFB, SPARSITY_FORMATS
else:
    from .sub8_and_sparse import packTflFB, SPARSITY_FORMATS


parser = argparse.ArgumentParser()

"""
    Command line option to choose the packing format between firmware(cpu) and hardware(rival2) oriented format.
"""
parser.add_argument(
        "--sparsity_format",
        type=str,
        default=None,
        choices=SPARSITY_FORMATS,
        help="What type of sparse weight tensor format to use",
)
flag, unparsed = parser.parse_known_args()



def main():
    if len(sys.argv) < 3:
        supported = SPARSITY_FORMATS.join('|')
        print("Usage: " + sys.argv[0] + f"[--sparsity_format {supported} inputModel.tflite outputModel.tflite")
        sys.exit(1)

    packTflFB(unparsed[0], unparsed[1], flag.sparsity_format)

    #printModel(m)


if __name__ == "__main__":
    main()
  